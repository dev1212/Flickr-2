
function ajaxProcess() {

var searchTerm = "nyc"; // get the user-entered search term
//var URL2='http://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=e73c3c2e11d5780e5370d864dccff2cf&'; 
var URL2='https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=7888e78655fadd46bd7c44c37c203ade&'; 
var tags="&tags="+ searchTerm;
var tagmode="&tagmode=any";
var jsonFormat = "&format=json";					
var ajaxURL= URL2+"per_page="+perpage+"&page="+currentPage+tags+tagmode+jsonFormat;
					//var ajaxURL= URL+"?"+tags+tagmode+jsonFormat;
					
				 $.ajax({
				  url:ajaxURL,
				  dataType:"jsonp",
				  jsonp:"jsoncallback",
				  success: function(data) {
					   // $("#photos").empty();	
						if(data.stat!="fail") {
							 console.log(data);	
							//$("#photos").empty();
							// $("figure").empty();
							$.each(data.photos.photo, function(i,photo) {
  							 // $("<figure></figure>").hide().append('<img src="http://farm'+photo.farm+'.static.flickr.com/'+photo.server+'/'+photo.id+'_'+photo.secret+'_q.jpg"/>').appendTo("#photos").fadeIn(2000);	
							  
							  var photoHTML="";
							  photoHTML+= "<div class='feed-b'> <img src='";
							  photoHTML+="http://farm"+photo.farm+".static.flickr.com/"+photo.server+"/"+photo.id+"_"+photo.secret+"_s.jpg'"; 
							  photoHTML+=" title='"+photo.title+"'" ;
							  //photoHTML+="></figure>";
							   photoHTML+=" ><p>"+photo.title+"</p></div>" ;
							   //photoHTML+="<figurecaption>"+photo.title+"</figurecaption><br>";
							  $("#gallery").append(photoHTML).fadeIn(200);
							  
							  
							});
							
						}else {
							 $("#gallery").empty();
							 console.log("Error code "+data.stat);
							 photoHTML="Error !! Error !! "+data.stat;
							 $("#gallery").append(photoHTML).fadeIn(200);
							 	
						}
						
					}
			     });
			    
	
}

var perpage=3;
var currentPage=1;

$(document).ready(function() {
	$("#gallery").empty();						  

				/**********************/
				
				ajaxProcess();
				/**************************/	

	
	$("#clear").click(function(){
			$("#gallery").empty();				   
	});


 
});



